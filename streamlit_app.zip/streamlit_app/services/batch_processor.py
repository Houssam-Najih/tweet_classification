"""
Batch Processor for Large Dataset Classification
Implements efficient batch processing with progress tracking
"""

import pandas as pd
import streamlit as st
from typing import Callable, List, Dict, Any, Optional
import logging
from datetime import datetime
import time

logger = logging.getLogger(__name__)


class BatchProcessor:
    """Handles batch processing of large datasets with progress tracking"""
    
    def __init__(self, batch_size: int = 50):
        """
        Initialize batch processor
        
        Args:
            batch_size: Number of items to process in each batch
        """
        self.batch_size = batch_size
        
    def process_in_batches(
        self,
        df: pd.DataFrame,
        process_func: Callable,
        progress_callback: Optional[Callable] = None,
        show_progress: bool = True
    ) -> pd.DataFrame:
        """
        Process DataFrame in batches with progress tracking
        
        Args:
            df: DataFrame to process
            process_func: Function to apply to each batch
            progress_callback: Optional callback for progress updates
            show_progress: Whether to show Streamlit progress bar
            
        Returns:
            Processed DataFrame
        """
        if df.empty:
            logger.warning("Empty DataFrame provided to batch processor")
            return df
            
        total_rows = len(df)
        total_batches = (total_rows + self.batch_size - 1) // self.batch_size
        
        logger.info(f"Processing {total_rows:,} rows in {total_batches} batches of {self.batch_size}")
        
        # Initialize progress tracking
        progress_bar = None
        status_text = None
        
        if show_progress:
            progress_bar = st.progress(0)
            status_text = st.empty()
        
        results = []
        start_time = time.time()
        
        try:
            for batch_idx in range(total_batches):
                start_idx = batch_idx * self.batch_size
                end_idx = min(start_idx + self.batch_size, total_rows)
                
                # Extract batch
                batch_df = df.iloc[start_idx:end_idx].copy()
                
                # Process batch
                batch_result = process_func(batch_df)
                results.append(batch_result)
                
                # Update progress
                progress = (batch_idx + 1) / total_batches
                processed_count = end_idx
                
                if show_progress and progress_bar and status_text:
                    progress_bar.progress(progress)
                    elapsed = time.time() - start_time
                    rate = processed_count / elapsed if elapsed > 0 else 0
                    eta = (total_rows - processed_count) / rate if rate > 0 else 0
                    
                    status_text.text(
                        f"📊 Traitement: {processed_count:,}/{total_rows:,} lignes "
                        f"({progress*100:.1f}%) | "
                        f"⚡ {rate:.1f} lignes/s | "
                        f"⏱️ ETA: {eta:.0f}s"
                    )
                
                if progress_callback:
                    progress_callback(
                        f"Batch {batch_idx + 1}/{total_batches}",
                        progress
                    )
                    
        except Exception as e:
            logger.error(f"Error in batch processing: {e}")
            if show_progress and progress_bar and status_text:
                progress_bar.empty()
                status_text.empty()
            raise
            
        finally:
            if show_progress and progress_bar and status_text:
                progress_bar.empty()
                status_text.empty()
        
        # Combine results
        result_df = pd.concat(results, ignore_index=True)
        
        total_time = time.time() - start_time
        logger.info(
            f"Batch processing complete: {total_rows:,} rows in {total_time:.2f}s "
            f"({total_rows/total_time:.1f} rows/s)"
        )
        
        return result_df
    
    def process_with_classification(
        self,
        df: pd.DataFrame,
        text_column: str,
        classifier: Any,
        show_progress: bool = True
    ) -> pd.DataFrame:
        """
        Specialized batch processing for classification tasks
        
        Args:
            df: DataFrame with texts to classify
            text_column: Name of column containing text
            classifier: Classifier object with classify_batch method
            show_progress: Whether to show progress bar
            
        Returns:
            DataFrame with classification results
        """
        def classify_batch(batch: pd.DataFrame) -> pd.DataFrame:
            """Classify a single batch"""
            texts = batch[text_column].tolist()
            results = classifier.classify_batch(texts)
            
            # Add results to batch
            for key, values in results.items():
                batch[key] = values
                
            return batch
        
        return self.process_in_batches(
            df,
            classify_batch,
            show_progress=show_progress
        )
    
    def estimate_processing_time(
        self,
        total_rows: int,
        time_per_item: float
    ) -> Dict[str, Any]:
        """
        Estimate processing time and batch configuration
        
        Args:
            total_rows: Total number of rows to process
            time_per_item: Estimated time per item in seconds
            
        Returns:
            Dictionary with time estimates and batch info
        """
        total_time = total_rows * time_per_item
        total_batches = (total_rows + self.batch_size - 1) // self.batch_size
        time_per_batch = self.batch_size * time_per_item
        
        return {
            'total_rows': total_rows,
            'batch_size': self.batch_size,
            'total_batches': total_batches,
            'estimated_total_time': total_time,
            'estimated_time_per_batch': time_per_batch,
            'estimated_rate': 1 / time_per_item if time_per_item > 0 else 0,
            'formatted_time': self._format_time(total_time)
        }
    
    @staticmethod
    def _format_time(seconds: float) -> str:
        """Format seconds into readable time string"""
        if seconds < 60:
            return f"{seconds:.0f}s"
        elif seconds < 3600:
            minutes = seconds / 60
            return f"{minutes:.1f}min"
        else:
            hours = seconds / 3600
            return f"{hours:.1f}h"


def create_batch_processor(batch_size: int = 50) -> BatchProcessor:
    """Factory function to create a batch processor instance"""
    return BatchProcessor(batch_size=batch_size)


# Example usage for CSV classification
def process_csv_with_batches(
    df: pd.DataFrame,
    text_column: str,
    batch_size: int = 50
) -> pd.DataFrame:
    """
    Process CSV data in batches for classification
    
    Args:
        df: Input DataFrame
        text_column: Column containing text to classify
        batch_size: Size of each batch
        
    Returns:
        Classified DataFrame
    """
    processor = BatchProcessor(batch_size=batch_size)
    
    st.info(f"🔄 Configuration: Traitement par lots de {batch_size} lignes")
    
    # Estimate time
    estimates = processor.estimate_processing_time(
        total_rows=len(df),
        time_per_item=0.1  # Adjust based on actual classifier speed
    )
    
    st.caption(
        f"📊 {estimates['total_batches']} lots • "
        f"⏱️ Temps estimé: {estimates['formatted_time']}"
    )
    
    # Process (classifier would be provided in actual use)
    # result = processor.process_with_classification(df, text_column, classifier)
    
    return df
